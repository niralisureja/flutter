import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Greeting App',
      theme: ThemeData(
        primaryColor: Color.fromARGB(255, 162, 87, 197),  // Use a single custom color
      ),
      home: GreetingPage(),
    );
  }
}

class GreetingPage extends StatefulWidget {
  @override
  _GreetingPageState createState() => _GreetingPageState();
}

class _GreetingPageState extends State<GreetingPage> {
  final TextEditingController _usernameController = TextEditingController();
  String _username = '';

  void _showGreeting() {
    setState(() {
      _username = _usernameController.text;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Greeting App'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            TextField(
              controller: _usernameController,
              decoration: InputDecoration(
                labelText: 'Enter your username',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _showGreeting,
              child: Text('Show Greeting'),
            ),
            SizedBox(height: 20),
            if (_username.isNotEmpty)
              RichText(
                text: TextSpan(
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 197, 26, 154), // Default text color
                  ),
                  children: <TextSpan>[
                    TextSpan(text: 'Hello $_username! Welcome to '),
                    TextSpan(
                      text: 'NS world! ',
                      style: TextStyle(
                        color: Color.fromARGB(255, 30, 61, 163), // Pink color for "NS world!"
                      ),
                    ),
                    TextSpan(
                      text:
                          'We were eagerly anticipating your arrival, and we’re thrilled that the day is finally here.',
                    ),
                  ],
                ),
                textAlign: TextAlign.center,
              ),
            if (_username.isEmpty)
              Text(
                'Hello! Please enter your username.',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
          ],
        ),
      ),
    );
  }
}
