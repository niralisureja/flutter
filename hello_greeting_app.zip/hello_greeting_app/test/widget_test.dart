import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hello_greeting_app/main.dart';

void main() {
  testWidgets('Greeting message is shown when the button is pressed', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(MyApp());

    // Verify that the initial state shows no greeting message.
    expect(find.text('Hello! Please enter your username.'), findsNothing);
    expect(find.text('Hello John! Welcome to the Flutter app!'), findsNothing);

    // Enter a username in the text field.
    await tester.enterText(find.byType(TextField), 'John');

    // Tap the 'Show Greeting' button and trigger a frame.
    await tester.tap(find.byType(ElevatedButton));
    await tester.pump();

    // Verify that the greeting message is displayed.
    expect(find.text('Hello John! Welcome to the Flutter app!'), findsOneWidget);
  });
}
