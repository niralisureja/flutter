import 'dart:math'; // Importing the math library for pow function
import 'package:flutter/material.dart';

void main() => runApp(LoanCalculatorApp());

class LoanCalculatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Loan EMI Calculator',
      theme: ThemeData(
        primarySwatch: Colors.teal,
      ),
      home: LoanCalculatorPage(),
    );
  }
}

class LoanCalculatorPage extends StatefulWidget {
  @override
  _LoanCalculatorPageState createState() => _LoanCalculatorPageState();
}

class _LoanCalculatorPageState extends State<LoanCalculatorPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _principalController = TextEditingController();
  final TextEditingController _interestRateController = TextEditingController();
  final TextEditingController _tenureController = TextEditingController();
  String _interestType = 'Simple'; // Dropdown value
  double _emiResult = 0;

  void _calculateEMI() {
    final principal = double.tryParse(_principalController.text) ?? 0;
    final interestRate = double.tryParse(_interestRateController.text) ?? 0;
    final tenure = double.tryParse(_tenureController.text) ?? 0;

    if (principal > 0 && interestRate > 0 && tenure > 0) {
      double interest = interestRate / 100 / 12;
      double emi = 0;

      if (_interestType == 'Simple') {
        // Simple Interest EMI Calculation
        double totalInterest = (principal * interestRate * tenure) / 100;
        emi = (principal + totalInterest) / (tenure * 12);
      } else {
        // Compound Interest EMI Calculation
        double n = tenure * 12; // Total number of months
        emi = principal * interest * (pow((1 + interest), n)) / (pow((1 + interest), n) - 1);
      }

      setState(() {
        _emiResult = emi;
      });
    } else {
      setState(() {
        _emiResult = 0;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Loan EMI Calculator'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              TextFormField(
                controller: _principalController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: 'Loan Amount (Principal)'),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter principal amount';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _interestRateController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: 'Interest Rate (%)'),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter interest rate';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _tenureController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: 'Tenure (Years)'),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter tenure';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              DropdownButtonFormField<String>(
                value: _interestType,
                items: <String>['Simple', 'Compound']
                    .map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (newValue) {
                  setState(() {
                    _interestType = newValue!;
                  });
                },
                decoration: InputDecoration(labelText: 'Interest Type'),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _calculateEMI();
                  }
                },
                child: Text('Calculate EMI'),
              ),
              SizedBox(height: 20),
              Text(
                'EMI: ${_emiResult.toStringAsFixed(2)}',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.teal),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
