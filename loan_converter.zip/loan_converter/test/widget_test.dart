import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:loan_calculator/main.dart';

void main() {
  testWidgets('Loan EMI Calculator test', (WidgetTester tester) async {
    // Build our LoanCalculatorApp widget.
    await tester.pumpWidget(LoanCalculatorApp());

    // Find the input fields and button.
    final loanAmountField = find.byType(TextFormField).at(0);
    final interestRateField = find.byType(TextFormField).at(1);
    final tenureField = find.byType(TextFormField).at(2);
    final dropdownInterestType = find.byType(DropdownButtonFormField<String>);
    final calculateButton = find.text('Calculate EMI');
    final emiText = find.textContaining('EMI:');

    // Input test data for loan amount, interest rate, and tenure.
    await tester.enterText(loanAmountField, '10000'); // Loan Amount = 10000
    await tester.enterText(interestRateField, '5');    // Interest Rate = 5%
    await tester.enterText(tenureField, '2');         // Tenure = 2 years

    // Select the interest type as 'Simple' from dropdown.
    await tester.tap(dropdownInterestType);
    await tester.pumpAndSettle();
    await tester.tap(find.text('Simple').last);
    await tester.pumpAndSettle();

    // Press the 'Calculate EMI' button.
    await tester.tap(calculateButton);
    await tester.pump();

    // Verify if the EMI result is displayed correctly.
    expect(emiText, findsOneWidget);

    // Verify if EMI calculation is correct for the given inputs.
    // For Simple Interest (P = 10000, R = 5%, T = 2 years):
    // Total interest = (10000 * 5 * 2) / 100 = 1000
    // EMI = (Principal + Total Interest) / (2 * 12) = 11000 / 24 = 458.33
    expect(find.text('EMI: 458.33'), findsOneWidget);
  });
}
