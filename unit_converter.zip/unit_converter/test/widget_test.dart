import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:unit_converter/main.dart';

void main() {
  testWidgets('Unit Converter app UI test', (WidgetTester tester) async {
    // Build the Unit Converter app and trigger a frame.
    await tester.pumpWidget(UnitConverterApp());

    // Verify that the dropdown contains "Length" as one of the conversion options.
    expect(find.text('Length'), findsOneWidget);
    
    // Enter a value in the text field.
    await tester.enterText(find.byType(TextField), '1000');
    
    // Verify the entered text.
    expect(find.text('1000'), findsOneWidget);
    
    // Press the convert button.
    await tester.tap(find.byType(ElevatedButton));
    await tester.pump();
    
    // Verify the output is displayed.
    expect(find.textContaining('Output:'), findsOneWidget);
  });
}

