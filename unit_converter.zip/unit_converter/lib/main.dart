import 'package:flutter/material.dart';

void main() {
  runApp(UnitConverterApp());
}

class UnitConverterApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return NewWidget();
  }
}

class NewWidget extends StatelessWidget {
  const NewWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Unit Converter',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: UnitConverterHome(),
    );
  }
}

class UnitConverterHome extends StatefulWidget {
  @override
  _UnitConverterHomeState createState() => _UnitConverterHomeState();
}

class _UnitConverterHomeState extends State<UnitConverterHome> {
  final TextEditingController _inputController = TextEditingController();
  double _outputValue = 0.0;
  String _selectedUnit = 'Length';
  final Map<String, double> _conversionRates = {
    'Length': 1000,   // meters to kilometers
    'Weight': 1000,   // grams to kilograms
    'Temperature': 1, // Celsius to Celsius
    'Area': 10000,    // square meters to hectares
  };

  void _convert() {
    double input = double.tryParse(_inputController.text) ?? 0;
    setState(() {
      if (_selectedUnit == 'Temperature') {
        // Custom logic for temperature conversion
        _outputValue = (input * 9 / 5) + 32; // Celsius to Fahrenheit
      } else {
        _outputValue = input / _conversionRates[_selectedUnit]!;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Unit Converter'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            TextField(
              controller: _inputController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Enter value',
              ),
            ),
            DropdownButton<String>(
              value: _selectedUnit,
              onChanged: (String? newValue) {
                setState(() {
                  _selectedUnit = newValue!;
                });
              },
              items: <String>['Length', 'Weight', 'Temperature', 'Area']
                  .map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
            ElevatedButton(
              onPressed: _convert,
              child: Text('Convert'),
            ),
            Text(
              'Output: $_outputValue',
              style: TextStyle(fontSize: 24),
            ),
          ],
        ),
      ),
    );
  }
}
